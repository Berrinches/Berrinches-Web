import { Mail, MapPin, Phone, Instagram, Facebook } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-black text-white py-12 md:py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {/* Brand */}
          <div>
            <h3 className="text-2xl font-bold mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
              BERRINCHES
            </h3>
            <p className="text-xs text-gray-400 tracking-widest mb-4">•delicatessen•</p>
            <p className="text-sm text-gray-300 leading-relaxed">
              Tu capricho gourmet, merecido. Una cafetería boutique donde la indulgencia es un arte.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-[#D4AF37]">Enlaces</h4>
            <ul className="space-y-2">
              <li>
                <a href="/" className="text-gray-300 hover:text-[#00BFA5] transition-colors text-sm">
                  Inicio
                </a>
              </li>
              <li>
                <a href="/about" className="text-gray-300 hover:text-[#00BFA5] transition-colors text-sm">
                  Sobre Nosotros
                </a>
              </li>
              <li>
                <a href="/catalog" className="text-gray-300 hover:text-[#00BFA5] transition-colors text-sm">
                  Catálogo
                </a>
              </li>
              <li>
                <a href="/gallery" className="text-gray-300 hover:text-[#00BFA5] transition-colors text-sm">
                  Galería
                </a>
              </li>
              <li>
                <a href="/contact" className="text-gray-300 hover:text-[#00BFA5] transition-colors text-sm">
                  Contacto
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-[#D4AF37]">Contacto</h4>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <MapPin size={18} className="text-[#00BFA5] mt-1 flex-shrink-0" />
                <p className="text-sm text-gray-300">
                  Higuereta, Santiago de Surco<br />
                  Lima, Perú
                </p>
              </div>
              <div className="flex items-center gap-3">
                <Phone size={18} className="text-[#00BFA5] flex-shrink-0" />
                <a href="tel:+51" className="text-sm text-gray-300 hover:text-[#00BFA5] transition-colors">
                  +51 (1) XXXX-XXXX
                </a>
              </div>
              <div className="flex items-center gap-3">
                <Mail size={18} className="text-[#00BFA5] flex-shrink-0" />
                <a href="mailto:info@berrinches.pe" className="text-sm text-gray-300 hover:text-[#00BFA5] transition-colors">
                  info@berrinches.pe
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Social Links */}
        <div className="border-t border-gray-800 pt-8 mb-8">
          <div className="flex justify-center gap-6 mb-8">
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-400 hover:text-[#00BFA5] transition-colors"
              aria-label="Instagram"
            >
              <Instagram size={24} />
            </a>
            <a
              href="https://facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-400 hover:text-[#00BFA5] transition-colors"
              aria-label="Facebook"
            >
              <Facebook size={24} />
            </a>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-800 pt-8 text-center">
          <p className="text-sm text-gray-400">
            © {currentYear} BERRINCHES •delicatessen•. Todos los derechos reservados.
          </p>
          <p className="text-xs text-gray-500 mt-2">
            Diseñado con pasión para los amantes del buen vivir.
          </p>
        </div>
      </div>
    </footer>
  );
}
