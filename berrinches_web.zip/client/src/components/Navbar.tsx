import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/_core/hooks/useAuth';
import { getLoginUrl } from '@/const';
import { Menu, X } from 'lucide-react';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();
  const { user, logout, isAuthenticated } = useAuth();

  const navLinks = [
    { href: '/', label: 'Inicio' },
    { href: '/about', label: 'Sobre Nosotros' },
    { href: '/catalog', label: 'Catálogo' },
    { href: '/gallery', label: 'Galería' },
    { href: '/contact', label: 'Contacto' },
    { href: '/brand-identity', label: 'Identidad Visual' },
  ];

  const isActive = (href: string) => location === href;

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center gap-2 hover:opacity-80 transition-opacity cursor-pointer">
              <div className="text-2xl font-bold text-black" style={{ fontFamily: "'Playfair Display', serif" }}>
                BERRINCHES
              </div>
              <div className="text-xs text-gray-500 tracking-widest">•delicatessen•</div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <span
                  className={`text-sm font-semibold tracking-wide transition-colors cursor-pointer ${
                    isActive(link.href)
                      ? 'text-[#00BFA5] border-b-2 border-[#00BFA5] pb-1'
                      : 'text-black hover:text-[#00BFA5]'
                  }`}
                >
                  {link.label}
                </span>
              </Link>
            ))}
          </div>

          {/* Auth Section */}
          <div className="hidden md:flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <Link href="/dashboard">
                  <span className="text-sm font-semibold text-[#00BFA5] hover:text-[#009a88] transition-colors cursor-pointer">
                    Dashboard
                  </span>
                </Link>
                <button
                  onClick={() => logout()}
                  className="text-sm font-semibold text-gray-600 hover:text-black transition-colors"
                >
                  Salir
                </button>
              </>
            ) : (
              <a
                href={getLoginUrl()}
                className="px-4 py-2 bg-[#00BFA5] text-white text-sm font-semibold rounded-sm hover:bg-opacity-90 transition-all"
              >
                Acceso Privado
              </a>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 hover:bg-gray-100 rounded-sm transition-colors"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-gray-200 pt-4">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <span
                  className={`block py-2 text-sm font-semibold tracking-wide transition-colors cursor-pointer ${
                    isActive(link.href)
                      ? 'text-[#00BFA5]'
                      : 'text-black hover:text-[#00BFA5]'
                  }`}
                  onClick={() => setIsOpen(false)}
                >
                  {link.label}
                </span>
              </Link>
            ))}
            <div className="mt-4 pt-4 border-t border-gray-200 flex flex-col gap-2">
              {isAuthenticated ? (
                <>
                  <Link href="/dashboard">
                    <span
                      className="block py-2 text-sm font-semibold text-[#00BFA5] cursor-pointer"
                      onClick={() => setIsOpen(false)}
                    >
                      Dashboard
                    </span>
                  </Link>
                  <button
                    onClick={() => {
                      logout();
                      setIsOpen(false);
                    }}
                    className="text-left py-2 text-sm font-semibold text-gray-600 hover:text-black"
                  >
                    Salir
                  </button>
                </>
              ) : (
                <a
                  href={getLoginUrl()}
                  className="block w-full px-4 py-2 bg-[#00BFA5] text-white text-sm font-semibold rounded-sm hover:bg-opacity-90 transition-all text-center"
                >
                  Acceso Privado
                </a>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
