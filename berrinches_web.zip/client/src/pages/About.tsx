import { Heart, Target, Compass, Sparkles } from 'lucide-react';

export default function About() {
  const values = [
    { title: 'Autenticidad', description: 'Genuino, transparente y fiel a la calidad de nuestros orígenes artesanales.' },
    { title: 'Excelencia', description: 'Compromiso con la calidad premium en cada detalle.' },
    { title: 'Pasión', description: 'Amor por lo que hacemos, reflejado en cada producto.' },
    { title: 'Indulgencia Consciente', description: 'Celebramos el placer sin culpa, elevando cada capricho a arte.' },
    { title: 'Cercanía', description: 'Conexión genuina con nuestros clientes, creando un espacio acogedor.' },
    { title: 'Sofisticación', description: 'Elegancia en cada aspecto, desde el diseño hasta la presentación.' }
  ];

  return (
    <div className="w-full">
      <section className="bg-gradient-to-b from-gray-50 to-white py-20 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-black mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>
            Sobre Nosotros
          </h1>
          <p className="text-xl text-gray-600">
            Conoce el propósito, visión y valores que impulsan BERRINCHES.
          </p>
        </div>
      </section>

      <section className="py-20 px-4 bg-white">
        <div className="container mx-auto max-w-5xl">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-20">
            <div className="boutique-card p-8">
              <div className="flex items-center gap-4 mb-4">
                <Heart className="w-8 h-8 text-[#00BFA5]" />
                <h2 className="text-2xl font-bold text-black" style={{ fontFamily: "'Playfair Display', serif" }}>
                  Propósito
                </h2>
              </div>
              <p className="text-gray-700 leading-relaxed">
                Transformar los momentos cotidianos en experiencias indulgentes y memorables.
              </p>
            </div>

            <div className="boutique-card p-8">
              <div className="flex items-center gap-4 mb-4">
                <Target className="w-8 h-8 text-[#D4AF37]" />
                <h2 className="text-2xl font-bold text-black" style={{ fontFamily: "'Playfair Display', serif" }}>
                  Visión
                </h2>
              </div>
              <p className="text-gray-700 leading-relaxed">
                Ser la cafetería gourmet boutique referente en Lima.
              </p>
            </div>
          </div>

          <div className="bg-black text-white p-12 rounded-sm mb-20">
            <div className="flex items-center gap-4 mb-4">
              <Compass className="w-8 h-8 text-[#00BFA5]" />
              <h2 className="text-2xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
                Misión
              </h2>
            </div>
            <p className="text-lg text-gray-300 leading-relaxed">
              Seleccionar y preparar cuidadosamente los mejores productos en un espacio acogedor.
            </p>
          </div>

          <div>
            <h2 className="text-3xl font-bold text-black mb-12 text-center" style={{ fontFamily: "'Playfair Display', serif" }}>
              Nuestros Valores
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {values.map((valor, idx) => (
                <div key={idx} className="boutique-card p-6">
                  <h3 className="text-xl font-bold text-[#00BFA5] mb-3">
                    {valor.title}
                  </h3>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {valor.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="bg-gray-50 py-20 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="flex items-center gap-4 mb-8">
            <Sparkles className="w-8 h-8 text-[#00BFA5]" />
            <h2 className="text-3xl font-bold text-black" style={{ fontFamily: "'Playfair Display', serif" }}>
              ADN de Marca
            </h2>
          </div>
          <div className="bg-white p-12 rounded-sm border border-gray-200">
            <p className="text-lg text-gray-700 leading-relaxed mb-6">
              <strong>Fusión magistral entre tradición artesanal y sofisticación boutique.</strong>
            </p>
            <div className="border-l-4 border-[#00BFA5] pl-6">
              <p className="text-2xl italic text-black" style={{ fontFamily: "'Playfair Display', serif" }}>
                "BERRINCHES es el placer auténtico de un capricho excepcional."
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
