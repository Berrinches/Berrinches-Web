import { useState, useEffect } from 'react';
import { trpc } from '@/lib/trpc';
import { ShoppingCart } from 'lucide-react';

interface Product {
  id: number;
  categoryId: number;
  name: string;
  description: string | null;
  price: number;
  imageUrl: string | null;
  isAvailable: string | null;
  createdAt: Date;
  updatedAt: Date;
}

interface Category {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  displayOrder: number | null;
  createdAt: Date;
  updatedAt: Date;
}

export default function Catalog() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  const { data: categoriesData, isLoading: categoriesLoading } = trpc.products.categories.useQuery();
  const { data: allProducts, isLoading: productsLoading } = trpc.products.all.useQuery();

  useEffect(() => {
    if (categoriesData) {
      setCategories(categoriesData);
      if (categoriesData.length > 0) {
        setSelectedCategory(categoriesData[0].slug);
      }
    }
  }, [categoriesData]);

  useEffect(() => {
    if (allProducts) {
      if (selectedCategory) {
        const category = categories.find(c => c.slug === selectedCategory);
        if (category) {
          const filtered = allProducts.filter(p => p.categoryId === category.id);
          setProducts(filtered);
        }
      } else {
        setProducts(allProducts);
      }
    }
    setLoading(false);
  }, [allProducts, selectedCategory, categories]);

  const formatPrice = (price: number) => {
    return (price / 100).toLocaleString('es-PE', {
      style: 'currency',
      currency: 'PEN'
    });
  };

  if (categoriesLoading || productsLoading || loading) {
    return (
      <div className="w-full min-h-screen bg-gray-50 py-20 px-4 flex items-center justify-center">
        <p className="text-gray-600">Cargando catálogo...</p>
      </div>
    );
  }

  return (
    <div className="w-full bg-gray-50">
      <section className="bg-gradient-to-b from-white to-gray-50 py-16 px-4">
        <div className="container mx-auto max-w-5xl text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-black mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>
            Catálogo de Productos
          </h1>
          <p className="text-xl text-gray-600">
            Descubre nuestra selección de productos gourmet organizados por categoría.
          </p>
        </div>
      </section>

      <section className="py-12 px-4 bg-white border-b border-gray-200">
        <div className="container mx-auto max-w-5xl">
          <div className="flex flex-wrap gap-3 justify-center">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-6 py-2 rounded-sm font-semibold transition-all ${
                selectedCategory === null
                  ? 'bg-[#00BFA5] text-white'
                  : 'bg-gray-100 text-black hover:bg-gray-200'
              }`}
            >
              Todos
            </button>
            {categories.map(category => (
              <button
                key={category.slug}
                onClick={() => setSelectedCategory(category.slug)}
                className={`px-6 py-2 rounded-sm font-semibold transition-all ${
                  selectedCategory === category.slug
                    ? 'bg-[#00BFA5] text-white'
                    : 'bg-gray-100 text-black hover:bg-gray-200'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4">
        <div className="container mx-auto max-w-5xl">
          {products.length === 0 ? (
            <div className="text-center py-20">
              <ShoppingCart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600 text-lg">No hay productos disponibles.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {products.map(product => (
                <div key={product.id} className="boutique-card overflow-hidden hover:shadow-xl transition-shadow">
                  <div className="h-64 bg-gray-200 overflow-hidden flex items-center justify-center">
                    {product.imageUrl ? (
                      <img
                        src={product.imageUrl}
                        alt={product.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <ShoppingCart className="w-12 h-12 text-gray-400" />
                    )}
                  </div>

                  <div className="p-6">
                    <h3 className="text-xl font-bold text-black mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                      {product.name}
                    </h3>
                    <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                      {product.description || 'Producto de calidad premium'}
                    </p>

                    <div className="flex items-center justify-between mb-4">
                      <span className="text-2xl font-bold text-[#00BFA5]">
                        {formatPrice(product.price)}
                      </span>
                      <span className={`text-xs font-semibold px-3 py-1 rounded-sm ${
                        product.isAvailable === 'available'
                          ? 'bg-green-100 text-green-700'
                          : 'bg-red-100 text-red-700'
                      }`}>
                        {product.isAvailable === 'available' ? 'Disponible' : 'Agotado'}
                      </span>
                    </div>

                    <button className="btn-primary w-full flex items-center justify-center gap-2">
                      <ShoppingCart size={18} />
                      Agregar
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
