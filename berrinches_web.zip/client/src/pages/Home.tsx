import { Link } from 'wouter';
import { ArrowRight, Coffee, Cake, UtensilsCrossed } from 'lucide-react';

export default function Home() {
  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="min-h-screen bg-gradient-to-b from-white via-white to-gray-50 flex items-center justify-center py-20 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <div className="mb-8 animate-fade-in-up">
            <h1
              className="text-5xl md:text-7xl font-bold text-black mb-4"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              BERRINCHES
            </h1>
            <p className="text-lg md:text-xl text-gray-500 tracking-widest mb-8">
              •delicatessen•
            </p>
          </div>

          <div className="mb-12 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
            <h2
              className="text-3xl md:text-5xl font-bold text-black mb-6"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Tu capricho gourmet,
              <span className="text-[#00BFA5] block">merecido</span>
            </h2>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto leading-relaxed">
              Una cafetería gourmet boutique donde la indulgencia es un arte. Descubre la fusión perfecta de café de especialidad, pastelería artesanal y charcutería fina en el corazón de Higuereta.
            </p>
          </div>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16 animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
            <Link href="/catalog">
              <span className="btn-primary inline-flex items-center justify-center gap-2 cursor-pointer">
                Explorar Menú
                <ArrowRight size={20} />
              </span>
            </Link>
            <Link href="/contact">
              <span className="btn-secondary inline-flex items-center justify-center gap-2 cursor-pointer">
                Conocer Ubicación
                <ArrowRight size={20} />
              </span>
            </Link>
          </div>

          {/* Feature Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-20">
            <div className="boutique-card p-8 text-center animate-fade-in-up" style={{ animationDelay: '0.6s' }}>
              <Coffee className="w-12 h-12 text-[#00BFA5] mx-auto mb-4" />
              <h3 className="text-xl font-bold text-black mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                Café de Especialidad
              </h3>
              <p className="text-gray-600 text-sm">
                Granos seleccionados cuidadosamente, preparados con maestría.
              </p>
            </div>

            <div className="boutique-card p-8 text-center animate-fade-in-up" style={{ animationDelay: '0.8s' }}>
              <Cake className="w-12 h-12 text-[#D4AF37] mx-auto mb-4" />
              <h3 className="text-xl font-bold text-black mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                Pastelería Artesanal
              </h3>
              <p className="text-gray-600 text-sm">
                Creaciones dulces hechas con ingredientes premium y pasión.
              </p>
            </div>

            <div className="boutique-card p-8 text-center animate-fade-in-up" style={{ animationDelay: '1s' }}>
              <UtensilsCrossed className="w-12 h-12 text-[#A0A0A0] mx-auto mb-4" />
              <h3 className="text-xl font-bold text-black mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                Charcutería Fina
              </h3>
              <p className="text-gray-600 text-sm">
                Fiambres frescos y productos gourmet de primera calidad.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Brand Statement Section */}
      <section className="bg-black text-white py-20 px-4">
        <div className="container mx-auto max-w-3xl text-center">
          <h2
            className="text-4xl md:text-5xl font-bold mb-8"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            La Celebración del Antojo Merecido
          </h2>
          <p className="text-lg text-gray-300 leading-relaxed mb-8">
            No juzgamos el impulso, lo elevamos a una forma de arte. BERRINCHES es el cómplice de tus pequeños grandes placeres cotidianos, un espacio donde cada capricho es celebrado con excelencia y sofisticación.
          </p>
          <div className="w-16 h-1 bg-[#00BFA5] mx-auto"></div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gray-50 py-20 px-4">
        <div className="container mx-auto max-w-3xl text-center">
          <h2
            className="text-4xl font-bold text-black mb-6"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Visita BERRINCHES
          </h2>
          <p className="text-lg text-gray-600 mb-8">
            Ubicado en Higuereta, Santiago de Surco, Lima. Ven a experimentar la indulgencia merecida.
          </p>
          <Link href="/contact">
            <span className="btn-primary inline-flex items-center gap-2 cursor-pointer">
              Obtener Ubicación
              <ArrowRight size={20} />
            </span>
          </Link>
        </div>
      </section>
    </div>
  );
}
