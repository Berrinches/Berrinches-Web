import { Copy, Check } from 'lucide-react';
import { useState } from 'react';

interface ColorSwatch {
  name: string;
  hex: string;
  rgb: string;
  usage: string;
}

export default function BrandIdentity() {
  const [copiedColor, setCopiedColor] = useState<string | null>(null);

  const colors: ColorSwatch[] = [
    {
      name: 'Teal Boutique',
      hex: '#00BFA5',
      rgb: 'rgb(0, 191, 165)',
      usage: 'Color principal, botones, acentos'
    },
    {
      name: 'Black Elegance',
      hex: '#000000',
      rgb: 'rgb(0, 0, 0)',
      usage: 'Texto principal, bordes, fondos oscuros'
    },
    {
      name: 'White Pure',
      hex: '#FFFFFF',
      rgb: 'rgb(255, 255, 255)',
      usage: 'Fondos, espacios en blanco'
    },
    {
      name: 'Gold Accent',
      hex: '#D4AF37',
      rgb: 'rgb(212, 175, 55)',
      usage: 'Detalles premium, acentos dorados'
    },
    {
      name: 'Gray Neutral',
      hex: '#A0A0A0',
      rgb: 'rgb(160, 160, 160)',
      usage: 'Texto secundario, bordes sutiles'
    }
  ];

  const copyToClipboard = (text: string, color: string) => {
    navigator.clipboard.writeText(text);
    setCopiedColor(color);
    setTimeout(() => setCopiedColor(null), 2000);
  };

  return (
    <div className="w-full bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-white to-gray-50 py-16 px-4">
        <div className="container mx-auto max-w-5xl text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-black mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>
            Identidad Visual
          </h1>
          <p className="text-xl text-gray-600">
            Sistema de diseño completo para BERRINCHES •delicatessen•
          </p>
        </div>
      </section>

      {/* Paleta de Colores */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-5xl">
          <h2 className="text-4xl font-bold text-black mb-12 text-center" style={{ fontFamily: "'Playfair Display', serif" }}>
            Paleta de Colores
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            {colors.map((color) => (
              <div key={color.hex} className="boutique-card overflow-hidden">
                <div
                  className="h-32 w-full transition-transform hover:scale-105"
                  style={{ backgroundColor: color.hex }}
                />
                <div className="p-4">
                  <h3 className="font-bold text-black mb-2">{color.name}</h3>
                  <div className="space-y-2">
                    <div className="text-xs">
                      <p className="text-gray-600 font-semibold">HEX</p>
                      <button
                        onClick={() => copyToClipboard(color.hex, color.hex)}
                        className="flex items-center gap-2 text-gray-700 hover:text-[#00BFA5] transition-colors"
                      >
                        <code className="text-xs">{color.hex}</code>
                        {copiedColor === color.hex ? (
                          <Check size={14} className="text-green-600" />
                        ) : (
                          <Copy size={14} />
                        )}
                      </button>
                    </div>
                    <div className="text-xs">
                      <p className="text-gray-600 font-semibold">RGB</p>
                      <button
                        onClick={() => copyToClipboard(color.rgb, color.hex + '-rgb')}
                        className="flex items-center gap-2 text-gray-700 hover:text-[#00BFA5] transition-colors"
                      >
                        <code className="text-xs">{color.rgb}</code>
                        {copiedColor === color.hex + '-rgb' ? (
                          <Check size={14} className="text-green-600" />
                        ) : (
                          <Copy size={14} />
                        )}
                      </button>
                    </div>
                  </div>
                  <p className="text-xs text-gray-600 mt-3">{color.usage}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Tipografía */}
      <section className="bg-white py-20 px-4 border-t border-gray-200">
        <div className="container mx-auto max-w-5xl">
          <h2 className="text-4xl font-bold text-black mb-12 text-center" style={{ fontFamily: "'Playfair Display', serif" }}>
            Tipografía
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Playfair Display */}
            <div className="boutique-card p-8">
              <h3 className="text-2xl font-bold text-black mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
                Playfair Display
              </h3>
              <p className="text-gray-600 mb-6">
                Tipografía serif elegante y sofisticada. Utilizada para títulos, headings y elementos principales que requieren impacto visual.
              </p>
              <div className="space-y-4">
                <div>
                  <p className="text-xs text-gray-600 font-semibold mb-1">H1 - 64px</p>
                  <p className="text-5xl font-bold text-black" style={{ fontFamily: "'Playfair Display', serif" }}>
                    Elegancia Boutique
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-600 font-semibold mb-1">H2 - 48px</p>
                  <p className="text-4xl font-bold text-black" style={{ fontFamily: "'Playfair Display', serif" }}>
                    Diseño Premium
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-600 font-semibold mb-1">H3 - 32px</p>
                  <p className="text-2xl font-bold text-black" style={{ fontFamily: "'Playfair Display', serif" }}>
                    Sofisticación
                  </p>
                </div>
              </div>
              <p className="text-xs text-gray-500 mt-6">
                <strong>Uso:</strong> Títulos principales, headings, nombres de categorías, elementos destacados
              </p>
            </div>

            {/* Montserrat */}
            <div className="boutique-card p-8">
              <h3 className="text-2xl font-bold text-black mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
                Montserrat
              </h3>
              <p className="text-gray-600 mb-6">
                Tipografía sans-serif moderna y legible. Utilizada para cuerpo de texto, descripciones y contenido secundario.
              </p>
              <div className="space-y-4">
                <div>
                  <p className="text-xs text-gray-600 font-semibold mb-1">Body - 16px</p>
                  <p className="text-base font-normal text-gray-700" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                    Texto principal con claridad y legibilidad óptimas para lectura prolongada
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-600 font-semibold mb-1">Small - 14px</p>
                  <p className="text-sm font-normal text-gray-600" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                    Texto secundario, descripciones de productos y detalles
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-600 font-semibold mb-1">Caption - 12px</p>
                  <p className="text-xs font-normal text-gray-500" style={{ fontFamily: "'Montserrat', sans-serif" }}>
                    Información adicional, etiquetas y metadatos
                  </p>
                </div>
              </div>
              <p className="text-xs text-gray-500 mt-6">
                <strong>Uso:</strong> Cuerpo de texto, descripciones, botones, navegación, contenido general
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Sistema de Diseño */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-5xl">
          <h2 className="text-4xl font-bold text-black mb-12 text-center" style={{ fontFamily: "'Playfair Display', serif" }}>
            Sistema de Diseño
          </h2>

          <div className="space-y-8">
            {/* Botones */}
            <div className="boutique-card p-8">
              <h3 className="text-2xl font-bold text-black mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>
                Botones
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <p className="text-sm font-semibold text-gray-700 mb-3">Primario</p>
                  <button className="btn-primary w-full">
                    Acción Principal
                  </button>
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-700 mb-3">Secundario</p>
                  <button className="btn-secondary w-full">
                    Acción Secundaria
                  </button>
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-700 mb-3">Gold</p>
                  <button className="btn-gold w-full">
                    Premium
                  </button>
                </div>
              </div>
            </div>

            {/* Tarjetas */}
            <div className="boutique-card p-8">
              <h3 className="text-2xl font-bold text-black mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>
                Tarjetas (Cards)
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="boutique-card p-6">
                  <h4 className="font-bold text-black mb-2">Tarjeta Estándar</h4>
                  <p className="text-gray-600 text-sm">
                    Componente reutilizable para mostrar contenido agrupado con bordes sutiles y espaciado elegante.
                  </p>
                </div>
                <div className="boutique-card p-6 border-l-4 border-[#00BFA5]">
                  <h4 className="font-bold text-black mb-2">Tarjeta Destacada</h4>
                  <p className="text-gray-600 text-sm">
                    Variante con borde izquierdo en teal para elementos que requieren mayor atención.
                  </p>
                </div>
              </div>
            </div>

            {/* Espaciado */}
            <div className="boutique-card p-8">
              <h3 className="text-2xl font-bold text-black mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>
                Espaciado
              </h3>
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-8 h-8 bg-[#00BFA5]"></div>
                  <p className="text-gray-700"><strong>8px</strong> - Unidad base de espaciado</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-8 bg-[#00BFA5]"></div>
                  <p className="text-gray-700"><strong>16px</strong> - Espaciado interno de componentes</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-24 h-8 bg-[#00BFA5]"></div>
                  <p className="text-gray-700"><strong>32px</strong> - Espaciado entre secciones</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-40 h-8 bg-[#00BFA5]"></div>
                  <p className="text-gray-700"><strong>80px</strong> - Espaciado entre bloques principales</p>
                </div>
              </div>
            </div>

            {/* Bordes y Sombras */}
            <div className="boutique-card p-8">
              <h3 className="text-2xl font-bold text-black mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>
                Bordes y Sombras
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="border-2 border-gray-300 p-6 rounded-sm">
                  <p className="text-sm font-semibold text-gray-700 mb-3">Borde Sutil</p>
                  <p className="text-gray-600 text-sm">
                    Borde de 2px en gris claro para separar elementos sin ser invasivo
                  </p>
                </div>
                <div className="shadow-lg p-6 rounded-sm bg-white">
                  <p className="text-sm font-semibold text-gray-700 mb-3">Sombra Elegante</p>
                  <p className="text-gray-600 text-sm">
                    Sombra suave para crear profundidad y jerarquía visual
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Principios de Diseño */}
      <section className="bg-white py-20 px-4 border-t border-gray-200">
        <div className="container mx-auto max-w-5xl">
          <h2 className="text-4xl font-bold text-black mb-12 text-center" style={{ fontFamily: "'Playfair Display', serif" }}>
            Principios de Diseño
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="boutique-card p-6">
              <h3 className="text-xl font-bold text-black mb-3" style={{ fontFamily: "'Playfair Display', serif" }}>
                Elegancia Boutique
              </h3>
              <p className="text-gray-600">
                Cada elemento debe transmitir sofisticación y cuidado en los detalles. Menos es más.
              </p>
            </div>
            <div className="boutique-card p-6">
              <h3 className="text-xl font-bold text-black mb-3" style={{ fontFamily: "'Playfair Display', serif" }}>
                Autenticidad
              </h3>
              <p className="text-gray-600">
                Reflejar la naturaleza artesanal y premium de nuestros productos en cada interacción.
              </p>
            </div>
            <div className="boutique-card p-6">
              <h3 className="text-xl font-bold text-black mb-3" style={{ fontFamily: "'Playfair Display', serif" }}>
                Claridad Visual
              </h3>
              <p className="text-gray-600">
                Jerarquía clara, espaciado generoso y tipografía legible para experiencia óptima.
              </p>
            </div>
            <div className="boutique-card p-6">
              <h3 className="text-xl font-bold text-black mb-3" style={{ fontFamily: "'Playfair Display', serif" }}>
                Experiencia Juguetona
              </h3>
              <p className="text-gray-600">
                Toques de humor y creatividad que reflejan la personalidad única de BERRINCHES.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
