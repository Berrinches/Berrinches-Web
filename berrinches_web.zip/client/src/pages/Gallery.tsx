import { ImageIcon, X } from 'lucide-react';
import { useState } from 'react';

interface GalleryImage {
  id: number;
  title: string;
  category: string;
  image: string;
}

export default function Gallery() {
  const [selectedImage, setSelectedImage] = useState<GalleryImage | null>(null);

  const galleryImages: GalleryImage[] = [
    {
      id: 1,
      title: 'Ambiente Boutique',
      category: 'Interior',
      image: 'https://via.placeholder.com/400x300?text=Ambiente+Boutique'
    },
    {
      id: 2,
      title: 'Café de Especialidad',
      category: 'Productos',
      image: 'https://via.placeholder.com/400x300?text=Cafe+Especialidad'
    },
    {
      id: 3,
      title: 'Pastelería Artesanal',
      category: 'Productos',
      image: 'https://via.placeholder.com/400x300?text=Pasteleria'
    },
    {
      id: 4,
      title: 'Charcutería Fina',
      category: 'Productos',
      image: 'https://via.placeholder.com/400x300?text=Charcuteria'
    },
    {
      id: 5,
      title: 'Experiencia de Marca',
      category: 'Experiencia',
      image: 'https://via.placeholder.com/400x300?text=Experiencia'
    },
    {
      id: 6,
      title: 'Detalles Gourmet',
      category: 'Productos',
      image: 'https://via.placeholder.com/400x300?text=Detalles'
    }
  ];

  return (
    <div className="w-full bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-white to-gray-50 py-16 px-4">
        <div className="container mx-auto max-w-5xl text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-black mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>
            Galería Visual
          </h1>
          <p className="text-xl text-gray-600">
            Explora el ambiente boutique, nuestros productos y la experiencia BERRINCHES
          </p>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-5xl">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {galleryImages.map((img) => (
              <div
                key={img.id}
                onClick={() => setSelectedImage(img)}
                className="boutique-card overflow-hidden h-64 cursor-pointer group hover:shadow-xl transition-all duration-300"
              >
                <div className="relative w-full h-full overflow-hidden bg-gray-200">
                  <img
                    src={img.image}
                    alt={img.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300 flex items-end">
                    <div className="w-full p-4 bg-gradient-to-t from-black to-transparent text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <h3 className="font-bold">{img.title}</h3>
                      <p className="text-sm text-gray-300">{img.category}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Modal Lightbox */}
      {selectedImage && (
        <div
          className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4"
          onClick={() => setSelectedImage(null)}
        >
          <div
            className="relative max-w-2xl w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute -top-12 right-0 text-white hover:text-gray-300 transition-colors"
            >
              <X size={32} />
            </button>
            <img
              src={selectedImage.image}
              alt={selectedImage.title}
              className="w-full h-auto rounded-sm"
            />
            <div className="bg-black text-white p-6 rounded-b-sm">
              <h2 className="text-2xl font-bold mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                {selectedImage.title}
              </h2>
              <p className="text-gray-400">{selectedImage.category}</p>
            </div>
          </div>
        </div>
      )}

      {/* Moodboard Section */}
      <section className="bg-white py-20 px-4 border-t border-gray-200">
        <div className="container mx-auto max-w-5xl text-center">
          <h2 className="text-3xl font-bold text-black mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>
            Concepto Visual
          </h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            BERRINCHES combina elegancia boutique con un toque juguetón. Nuestro diseño refleja sofisticación, 
            autenticidad y una pasión por los detalles gourmet. Cada elemento visual cuenta la historia de una 
            experiencia de indulgencia merecida en el corazón de Higuereta.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="boutique-card p-6">
              <div className="w-12 h-12 bg-[#00BFA5] rounded-sm mb-4"></div>
              <h3 className="font-bold text-black mb-2">Teal Boutique</h3>
              <p className="text-sm text-gray-600">Color principal que transmite frescura y sofisticación</p>
            </div>
            <div className="boutique-card p-6">
              <div className="w-12 h-12 bg-[#D4AF37] rounded-sm mb-4"></div>
              <h3 className="font-bold text-black mb-2">Gold Accent</h3>
              <p className="text-sm text-gray-600">Detalles dorados para elegancia y lujo</p>
            </div>
            <div className="boutique-card p-6">
              <div className="w-12 h-12 bg-[#000000] rounded-sm mb-4"></div>
              <h3 className="font-bold text-black mb-2">Black Elegance</h3>
              <p className="text-sm text-gray-600">Base sofisticada y minimalista</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
