import { useAuth } from '@/_core/hooks/useAuth';
import { getLoginUrl } from '@/const';
import { trpc } from '@/lib/trpc';
import { BarChart3, Users, TrendingUp, AlertCircle, Target, Zap } from 'lucide-react';
import { useState } from 'react';

export default function Dashboard() {
  const { user, isAuthenticated, loading } = useAuth();
  const [activeTab, setActiveTab] = useState<'overview' | 'competitors' | 'personas' | 'insights'>('overview');

  const { data: research, isLoading: researchLoading } = trpc.research.all.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: competitors, isLoading: competitorsLoading } = trpc.research.competitors.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: personas, isLoading: personasLoading } = trpc.research.personas.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: insights, isLoading: insightsLoading } = trpc.research.insights.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  if (loading) {
    return (
      <div className="w-full min-h-screen flex items-center justify-center">
        <p className="text-gray-600">Cargando...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="w-full min-h-screen bg-gray-50 flex items-center justify-center px-4">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-[#D4AF37] mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-black mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
            Acceso Restringido
          </h1>
          <p className="text-gray-600 mb-8">Debes iniciar sesión para acceder al dashboard.</p>
          <a
            href={getLoginUrl()}
            className="btn-primary inline-block"
          >
            Iniciar Sesión
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full min-h-screen bg-gray-50 py-12 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="mb-12">
          <h1 className="text-5xl font-bold text-black mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
            Dashboard Privado
          </h1>
          <p className="text-gray-600">Bienvenido, {user?.name || 'Usuario'} | Investigación de Mercado - BERRINCHES</p>
        </div>

        {/* Tabs de Navegación */}
        <div className="flex gap-4 mb-8 flex-wrap">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-6 py-2 rounded-sm font-semibold transition-all ${
              activeTab === 'overview'
                ? 'bg-[#00BFA5] text-white'
                : 'bg-white text-black border-2 border-gray-200 hover:border-[#00BFA5]'
            }`}
          >
            Resumen
          </button>
          <button
            onClick={() => setActiveTab('competitors')}
            className={`px-6 py-2 rounded-sm font-semibold transition-all ${
              activeTab === 'competitors'
                ? 'bg-[#00BFA5] text-white'
                : 'bg-white text-black border-2 border-gray-200 hover:border-[#00BFA5]'
            }`}
          >
            Competencia ({competitors?.length || 0})
          </button>
          <button
            onClick={() => setActiveTab('personas')}
            className={`px-6 py-2 rounded-sm font-semibold transition-all ${
              activeTab === 'personas'
                ? 'bg-[#00BFA5] text-white'
                : 'bg-white text-black border-2 border-gray-200 hover:border-[#00BFA5]'
            }`}
          >
            Buyer Personas ({personas?.length || 0})
          </button>
          <button
            onClick={() => setActiveTab('insights')}
            className={`px-6 py-2 rounded-sm font-semibold transition-all ${
              activeTab === 'insights'
                ? 'bg-[#00BFA5] text-white'
                : 'bg-white text-black border-2 border-gray-200 hover:border-[#00BFA5]'
            }`}
          >
            Insights ({insights?.length || 0})
          </button>
        </div>

        {/* Contenido por Tab */}
        {activeTab === 'overview' && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              <div className="boutique-card p-6">
                <BarChart3 className="w-8 h-8 text-[#00BFA5] mb-4" />
                <h3 className="font-bold text-black mb-2">Investigación</h3>
                <p className="text-2xl font-bold text-[#00BFA5]">{research?.length || 0}</p>
                <p className="text-sm text-gray-600">Estudios de mercado</p>
              </div>
              
              <div className="boutique-card p-6">
                <Users className="w-8 h-8 text-[#D4AF37] mb-4" />
                <h3 className="font-bold text-black mb-2">Competidores</h3>
                <p className="text-2xl font-bold text-[#D4AF37]">{competitors?.length || 0}</p>
                <p className="text-sm text-gray-600">Analizados</p>
              </div>
              
              <div className="boutique-card p-6">
                <Target className="w-8 h-8 text-[#A0A0A0] mb-4" />
                <h3 className="font-bold text-black mb-2">Buyer Personas</h3>
                <p className="text-2xl font-bold text-[#A0A0A0]">{personas?.length || 0}</p>
                <p className="text-sm text-gray-600">Perfiles identificados</p>
              </div>
              
              <div className="boutique-card p-6">
                <Zap className="w-8 h-8 text-[#00BFA5] mb-4" />
                <h3 className="font-bold text-black mb-2">Insights</h3>
                <p className="text-2xl font-bold text-[#00BFA5]">{insights?.length || 0}</p>
                <p className="text-sm text-gray-600">Hallazgos clave</p>
              </div>
            </div>

            <div className="boutique-card p-8">
              <h2 className="text-2xl font-bold text-black mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
                Resumen Ejecutivo
              </h2>
              <div className="space-y-4">
                <div className="border-l-4 border-[#00BFA5] pl-4 py-2">
                  <h3 className="font-bold text-black">Oportunidad de Mercado</h3>
                  <p className="text-sm text-gray-600">Existe demanda insatisfecha de cafeterías boutique con charcutería fina en Higuereta</p>
                </div>
                <div className="border-l-4 border-[#D4AF37] pl-4 py-2">
                  <h3 className="font-bold text-black">Diferenciación Única</h3>
                  <p className="text-sm text-gray-600">La combinación de café de especialidad + pastelería artesanal + charcutería fina es única</p>
                </div>
                <div className="border-l-4 border-[#A0A0A0] pl-4 py-2">
                  <h3 className="font-bold text-black">Posicionamiento</h3>
                  <p className="text-sm text-gray-600">Posicionar como "La Boutique Gourmet de Higuereta" con énfasis en autenticidad</p>
                </div>
              </div>
            </div>
          </>
        )}

        {activeTab === 'competitors' && (
          <div className="space-y-6">
            {competitorsLoading ? (
              <p className="text-gray-600">Cargando competencia...</p>
            ) : competitors && competitors.length > 0 ? (
              competitors.map((competitor: any) => (
                <div key={competitor.id} className="boutique-card p-6">
                  <h3 className="text-xl font-bold text-black mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
                    {competitor.name}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <p className="text-sm font-semibold text-gray-700 mb-2">Ubicación</p>
                      <p className="text-gray-600">{competitor.location}</p>
                      <p className="text-sm text-gray-500 mt-2">Tipo: {competitor.type === 'direct' ? 'Competencia Directa' : 'Competencia Indirecta'}</p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-700 mb-2">Fortalezas</p>
                      <p className="text-gray-600">{competitor.strengths}</p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-700 mb-2">Debilidades</p>
                      <p className="text-gray-600">{competitor.weaknesses}</p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-700 mb-2">Amenazas</p>
                      <p className="text-gray-600">{competitor.threats}</p>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-gray-600">No hay datos de competencia disponibles</p>
            )}
          </div>
        )}

        {activeTab === 'personas' && (
          <div className="space-y-6">
            {personasLoading ? (
              <p className="text-gray-600">Cargando buyer personas...</p>
            ) : personas && personas.length > 0 ? (
              personas.map((persona: any) => (
                <div key={persona.id} className="boutique-card p-6">
                  <h3 className="text-xl font-bold text-black mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
                    {persona.name}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <p className="text-sm font-semibold text-gray-700 mb-2">Rango de Edad</p>
                      <p className="text-gray-600">{persona.age_range}</p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-700 mb-2">Ingreso</p>
                      <p className="text-gray-600">{persona.income}</p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-700 mb-2">Estilo de Vida</p>
                      <p className="text-gray-600">{persona.lifestyle}</p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-700 mb-2">Puntos de Dolor</p>
                      <p className="text-gray-600">{persona.pain_points}</p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-700 mb-2">Motivaciones</p>
                      <p className="text-gray-600">{persona.motivations}</p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-700 mb-2">Canales Preferidos</p>
                      <p className="text-gray-600">{persona.preferred_channels}</p>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-gray-600">No hay buyer personas disponibles</p>
            )}
          </div>
        )}

        {activeTab === 'insights' && (
          <div className="space-y-6">
            {insightsLoading ? (
              <p className="text-gray-600">Cargando insights...</p>
            ) : insights && insights.length > 0 ? (
              insights.map((insight: any) => (
                <div key={insight.id} className="boutique-card p-6 border-l-4" style={{
                  borderLeftColor: insight.priority === 'high' ? '#00BFA5' : insight.priority === 'medium' ? '#D4AF37' : '#A0A0A0'
                }}>
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="text-xl font-bold text-black" style={{ fontFamily: "'Playfair Display', serif" }}>
                      {insight.title}
                    </h3>
                    <span className={`text-xs font-semibold px-3 py-1 rounded-sm ${
                      insight.priority === 'high' ? 'bg-green-100 text-green-700' :
                      insight.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {insight.priority === 'high' ? 'Alta' : insight.priority === 'medium' ? 'Media' : 'Baja'} Prioridad
                    </span>
                  </div>
                  <p className="text-gray-600 mb-2">{insight.insight}</p>
                  <p className="text-sm text-gray-500">Categoría: {insight.category}</p>
                </div>
              ))
            ) : (
              <p className="text-gray-600">No hay insights disponibles</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
