import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import { useEffect, useRef } from 'react';

export default function Contact() {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);

  useEffect(() => {
    const loadGoogleMaps = () => {
      if (window.google && mapRef.current && !mapInstanceRef.current) {
        const higueretaLocation = { lat: -12.1294, lng: -77.0000 };
        
        mapInstanceRef.current = new window.google.maps.Map(mapRef.current, {
          zoom: 16,
          center: higueretaLocation,
          mapTypeControl: true,
          fullscreenControl: true,
          streetViewControl: true,
        });

        new window.google.maps.Marker({
          position: higueretaLocation,
          map: mapInstanceRef.current,
          title: 'BERRINCHES delicatessen',
        });
      }
    };

    if (window.google) {
      loadGoogleMaps();
    } else {
      const timer = setTimeout(loadGoogleMaps, 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  return (
    <div className="w-full bg-gray-50">
      <section className="bg-gradient-to-b from-white to-gray-50 py-16 px-4">
        <div className="container mx-auto max-w-5xl text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-black mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>
            Contacto y Ubicación
          </h1>
          <p className="text-xl text-gray-600">
            Visítanos en nuestro boutique en Higuereta, Santiago de Surco
          </p>
        </div>
      </section>

      <section className="py-20 px-4">
        <div className="container mx-auto max-w-5xl">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Información de Contacto */}
            <div className="lg:col-span-1">
              <h2 className="text-3xl font-bold text-black mb-8" style={{ fontFamily: "'Playfair Display', serif" }}>
                Información
              </h2>
              
              <div className="space-y-6">
                <div className="flex gap-4">
                  <MapPin className="w-6 h-6 text-[#00BFA5] flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold text-black mb-1">Ubicación</h3>
                    <p className="text-gray-600 text-sm">Higuereta, Santiago de Surco<br />Lima, Perú</p>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <Phone className="w-6 h-6 text-[#00BFA5] flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold text-black mb-1">Teléfono</h3>
                    <p className="text-gray-600 text-sm">+51 (1) 2XXX-XXXX</p>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <Mail className="w-6 h-6 text-[#00BFA5] flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold text-black mb-1">Email</h3>
                    <p className="text-gray-600 text-sm">info@berrinches.pe</p>
                  </div>
                </div>
              </div>

              {/* Horarios */}
              <div className="boutique-card p-6 mt-8">
                <div className="flex gap-3 mb-4">
                  <Clock className="w-6 h-6 text-[#00BFA5] flex-shrink-0" />
                  <h3 className="text-xl font-bold text-black" style={{ fontFamily: "'Playfair Display', serif" }}>Horarios</h3>
                </div>
                <div className="space-y-2 text-gray-700 text-sm">
                  <p><strong>Lunes - Viernes:</strong> 7:00 AM - 8:00 PM</p>
                  <p><strong>Sábado:</strong> 8:00 AM - 9:00 PM</p>
                  <p><strong>Domingo:</strong> 9:00 AM - 7:00 PM</p>
                </div>
              </div>
            </div>

            {/* Mapa */}
            <div className="lg:col-span-2">
              <div 
                ref={mapRef} 
                className="w-full h-96 rounded-sm border-2 border-gray-200 shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
