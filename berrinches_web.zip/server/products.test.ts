import { describe, it, expect, beforeAll } from 'vitest';
import { appRouter } from './routers';

describe('Products Router', () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(() => {
    const mockContext = {
      user: null,
      req: {} as any,
      res: {} as any,
    };
    caller = appRouter.createCaller(mockContext);
  });

  describe('products.categories', () => {
    it('should return product categories', async () => {
      const categories = await caller.products.categories();
      expect(Array.isArray(categories)).toBe(true);
    });

    it('should return categories with required fields', async () => {
      const categories = await caller.products.categories();
      if (categories.length > 0) {
        const category = categories[0];
        expect(category).toHaveProperty('id');
        expect(category).toHaveProperty('name');
        expect(category).toHaveProperty('slug');
      }
    });
  });

  describe('products.all', () => {
    it('should return all available products', async () => {
      const products = await caller.products.all();
      expect(Array.isArray(products)).toBe(true);
    });

    it('should return products with required fields', async () => {
      const products = await caller.products.all();
      if (products.length > 0) {
        const product = products[0];
        expect(product).toHaveProperty('id');
        expect(product).toHaveProperty('name');
        expect(product).toHaveProperty('price');
        expect(product).toHaveProperty('categoryId');
      }
    });

    it('should only return available products', async () => {
      const products = await caller.products.all();
      products.forEach(product => {
        expect(product.isAvailable).toBe('available');
      });
    });
  });

  describe('products.byCategory', () => {
    it('should return products for a valid category slug', async () => {
      const products = await caller.products.byCategory({ slug: 'cafes-especialidad' });
      expect(Array.isArray(products)).toBe(true);
    });

    it('should return empty array for invalid category slug', async () => {
      const products = await caller.products.byCategory({ slug: 'invalid-category' });
      expect(Array.isArray(products)).toBe(true);
      expect(products.length).toBe(0);
    });
  });

  describe('products.byId', () => {
    it('should return a product by id', async () => {
      const products = await caller.products.all();
      if (products.length > 0) {
        const product = await caller.products.byId({ id: products[0].id });
        expect(product).not.toBeNull();
        expect(product?.id).toBe(products[0].id);
      }
    });

    it('should return null for invalid product id', async () => {
      const product = await caller.products.byId({ id: 99999 });
      expect(product).toBeNull();
    });
  });
});
