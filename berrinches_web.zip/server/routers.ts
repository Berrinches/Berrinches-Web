import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { getAllProductCategories, getProductsByCategorySlug, getAllProducts, getProductById, getAllMarketResearch, getMarketResearchByCategory, getAllCompetitors, getAllBuyerPersonas, getAllBrandInsights, getBrandInsightsByCategory } from "./db";
import { z } from "zod";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  products: router({
    categories: publicProcedure.query(async () => {
      return await getAllProductCategories();
    }),
    byCategory: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        return await getProductsByCategorySlug(input.slug);
      }),
    all: publicProcedure.query(async () => {
      return await getAllProducts();
    }),
    byId: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await getProductById(input.id);
      }),
  }),

  research: router({
    all: protectedProcedure.query(async ({ ctx }) => {
      // Only admin users can access research data
      if (ctx.user.role !== 'admin') {
        throw new Error('Unauthorized');
      }
      return await getAllMarketResearch();
    }),
    byCategory: protectedProcedure
      .input(z.object({ category: z.string() }))
      .query(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') {
          throw new Error('Unauthorized');
        }
        return await getMarketResearchByCategory(input.category);
      }),
    competitors: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new Error('Unauthorized');
      }
      return await getAllCompetitors();
    }),
    personas: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new Error('Unauthorized');
      }
      return await getAllBuyerPersonas();
    }),
    insights: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new Error('Unauthorized');
      }
      return await getAllBrandInsights();
    }),
    insightsByCategory: protectedProcedure
      .input(z.object({ category: z.string() }))
      .query(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') {
          throw new Error('Unauthorized');
        }
        return await getBrandInsightsByCategory(input.category);
      }),
  }),
});

export type AppRouter = typeof appRouter;
