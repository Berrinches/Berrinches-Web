import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, products, productCategories, marketResearch, competitors, buyerPersonas, brandInsights } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Product queries
export async function getAllProductCategories() {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db.select().from(productCategories).orderBy(productCategories.displayOrder);
  } catch (error) {
    console.error("[Database] Failed to get product categories:", error);
    return [];
  }
}

export async function getProductsByCategorySlug(slug: string) {
  const db = await getDb();
  if (!db) return [];
  
  try {
    const category = await db.select().from(productCategories).where(eq(productCategories.slug, slug)).limit(1);
    if (category.length === 0) return [];
    
    return await db.select().from(products).where(eq(products.categoryId, category[0].id));
  } catch (error) {
    console.error("[Database] Failed to get products by category:", error);
    return [];
  }
}

export async function getAllProducts() {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db.select().from(products).where(eq(products.isAvailable, "available"));
  } catch (error) {
    console.error("[Database] Failed to get all products:", error);
    return [];
  }
}

export async function getProductById(id: number) {
  const db = await getDb();
  if (!db) return null;
  
  try {
    const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[Database] Failed to get product by id:", error);
    return null;
  }
}

// Market research queries
export async function getMarketResearchByCategory(category: string) {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db.select().from(marketResearch).where(eq(marketResearch.category, category)).orderBy(desc(marketResearch.createdAt));
  } catch (error) {
    console.error("[Database] Failed to get market research:", error);
    return [];
  }
}

export async function getAllMarketResearch() {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db.select().from(marketResearch).orderBy(desc(marketResearch.createdAt));
  } catch (error) {
    console.error("[Database] Failed to get all market research:", error);
    return [];
  }
}

// Competitor queries
export async function getAllCompetitors() {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db.select().from(competitors);
  } catch (error) {
    console.error("[Database] Failed to get competitors:", error);
    return [];
  }
}

// Buyer personas queries
export async function getAllBuyerPersonas() {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db.select().from(buyerPersonas);
  } catch (error) {
    console.error("[Database] Failed to get buyer personas:", error);
    return [];
  }
}

// Brand insights queries
export async function getBrandInsightsByCategory(category: string) {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db.select().from(brandInsights).where(eq(brandInsights.category, category)).orderBy(desc(brandInsights.priority));
  } catch (error) {
    console.error("[Database] Failed to get brand insights:", error);
    return [];
  }
}

export async function getAllBrandInsights() {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db.select().from(brandInsights).orderBy(desc(brandInsights.priority));
  } catch (error) {
    console.error("[Database] Failed to get all brand insights:", error);
    return [];
  }
}
