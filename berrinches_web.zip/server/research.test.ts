import { describe, it, expect, beforeAll } from 'vitest';
import { appRouter } from './routers';
import type { TrpcContext } from './_core/context';

describe('Research Router (Protected)', () => {
  let adminCaller: ReturnType<typeof appRouter.createCaller>;
  let userCaller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(() => {
    const adminContext: TrpcContext = {
      user: {
        id: 1,
        openId: 'admin-user',
        email: 'admin@example.com',
        name: 'Admin User',
        loginMethod: 'manus',
        role: 'admin',
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      },
      req: {} as any,
      res: {} as any,
    };

    const userContext: TrpcContext = {
      user: {
        id: 2,
        openId: 'regular-user',
        email: 'user@example.com',
        name: 'Regular User',
        loginMethod: 'manus',
        role: 'user',
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      },
      req: {} as any,
      res: {} as any,
    };

    adminCaller = appRouter.createCaller(adminContext);
    userCaller = appRouter.createCaller(userContext);
  });

  describe('research.all', () => {
    it('should allow admin to access all research', async () => {
      const research = await adminCaller.research.all();
      expect(Array.isArray(research)).toBe(true);
    });

    it('should deny regular user access to research', async () => {
      try {
        await userCaller.research.all();
        expect.fail('Should have thrown an error');
      } catch (error: any) {
        expect(error.message).toContain('Unauthorized');
      }
    });
  });

  describe('research.competitors', () => {
    it('should allow admin to access competitors', async () => {
      const competitors = await adminCaller.research.competitors();
      expect(Array.isArray(competitors)).toBe(true);
    });

    it('should have competitor data with required fields', async () => {
      const competitors = await adminCaller.research.competitors();
      if (competitors.length > 0) {
        const competitor = competitors[0];
        expect(competitor).toHaveProperty('name');
        expect(competitor).toHaveProperty('location');
        expect(competitor).toHaveProperty('type');
      }
    });

    it('should deny regular user access to competitors', async () => {
      try {
        await userCaller.research.competitors();
        expect.fail('Should have thrown an error');
      } catch (error: any) {
        expect(error.message).toContain('Unauthorized');
      }
    });
  });

  describe('research.personas', () => {
    it('should allow admin to access buyer personas', async () => {
      const personas = await adminCaller.research.personas();
      expect(Array.isArray(personas)).toBe(true);
    });

    it('should have buyer personas with required fields', async () => {
      const personas = await adminCaller.research.personas();
      if (personas.length > 0) {
        const persona = personas[0];
        expect(persona).toHaveProperty('name');
        expect(persona).toHaveProperty('ageRange');
        expect(persona).toHaveProperty('income');
      }
    });

    it('should deny regular user access to personas', async () => {
      try {
        await userCaller.research.personas();
        expect.fail('Should have thrown an error');
      } catch (error: any) {
        expect(error.message).toContain('Unauthorized');
      }
    });
  });

  describe('research.insights', () => {
    it('should allow admin to access insights', async () => {
      const insights = await adminCaller.research.insights();
      expect(Array.isArray(insights)).toBe(true);
    });

    it('should have insights with required fields', async () => {
      const insights = await adminCaller.research.insights();
      if (insights.length > 0) {
        const insight = insights[0];
        expect(insight).toHaveProperty('title');
        expect(insight).toHaveProperty('insight');
        expect(insight).toHaveProperty('category');
        expect(insight).toHaveProperty('priority');
      }
    });

    it('should deny regular user access to insights', async () => {
      try {
        await userCaller.research.insights();
        expect.fail('Should have thrown an error');
      } catch (error: any) {
        expect(error.message).toContain('Unauthorized');
      }
    });
  });
});
